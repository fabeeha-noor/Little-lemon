import resturantFood from '../assets/restauranfood.jpg';
  
  const headerData = {
        title: "Little Lemon",
        location: "Chicago",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ab tempora deleniti eum repellat explicabo ratione quisquam fugiat quidem. Tempora eius deserunt corrupti esse nemo earum, a doloremque minus molestias! Quia.",
        btnname: "Reserve a Table",
        image: resturantFood
    }


export default headerData;