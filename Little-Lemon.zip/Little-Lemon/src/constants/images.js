import logo from '../assets/Logo.svg';
import greekSalad from '../assets/greekSalad.jpg';
import resturantFood from '../assets/restauranfood.jpg';
import lemonDessert from '../assets/lemonDessert.jpg';
import bruchetta from '../assets/bruchetta.svg';
import MarioandAdrianA from '../assets/MarioandAdrianA.jpg';
import MarioandAdrianb from '../assets/MarioandAdrianb.jpg';
import resturant from '../assets/restaurant.jpg';
import sajal from '../assets/Sajal.png';
import ramsha from '../assets/Ramsha.png';
import mawra from '../assets/Mawra.png';
import iqsf from '../assets/IQSF.png';
import resturantChefB from '../assets/restaurantChefB.jpg';
import bookingConfirmed from '../assets/bookingConfirmed.png';
import underConstruction from '../assets/underConstruction.PNG';

export default {logo, greekSalad, resturantFood, lemonDessert, bruchetta, MarioandAdrianA, MarioandAdrianb, resturant, sajal, ramsha, mawra, iqsf, resturantChefB, bookingConfirmed, underConstruction};