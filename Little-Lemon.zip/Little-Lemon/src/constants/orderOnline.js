import images from "./images";
  
  const OrderOnline = {
        title: `UNDER CONSTRUCTION`,
        location: "",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ab tempora deleniti eum repellat explicabo ratione quisquam fugiat quidem..",
        btnname: "Order",
        image: images.underConstruction
    }

export default OrderOnline;