import MarioandAdrianA from '../assets/MarioandAdrianA.jpg';
  
  const reservationData = {
        title: "Reserve",
        location: "A Table",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ab tempora deleniti eum repellat explicabo ratione quisquam fugiat quidem..",
        btnname: "Find Table",
        image: MarioandAdrianA
    }

export default reservationData;